package Athenaauthetication;

import java.lang.module.Configuration;

import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

@SpringBootApplication
public class AthenaautheticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AthenaautheticationApplication.class, args);
	}

	
}
